using UnityEngine;

public class PowerupManager : MonoBehaviour
{
    [Header("Powerup Type")]
    public bool isHealPowerup = false;
    public bool isInvincibilityPowerup = false;

    [Header("Lifetime")]
    public float lifetime = 10f;

    private void Start()
    {
        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        PlayerHealth hp = other.GetComponent<PlayerHealth>();
        if (hp == null) return;

        // Healing
        if (isHealPowerup)
            hp.TakeDamage(-25);

        // Invincibility
        if (isInvincibilityPowerup)
            hp.ActivateInvincibility(5f);

        Destroy(gameObject);
    }
}
