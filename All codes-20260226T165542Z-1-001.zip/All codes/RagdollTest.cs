using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(Animator))]
public class RagdollTest : MonoBehaviour
{
    [Tooltip("Optional reference to your AI locomotion script. If left empty the script will try to find one at Awake.")]
    public MonoBehaviour aiLocomotionReference; // assign in inspector or leave blank to auto-find

    private Rigidbody[] ragdollBodies;
    private Animator animator;
    private NavMeshAgent agent;
    private MonoBehaviour aiLocomotion; // actual reference to AI script

    [Header("NavMesh revert")]
    public float navMeshSampleDistance = 1f; // used if you re-enable the agent later

    private void Awake()
    {
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();

        // Try inspector-specified first, then try to find AiLocomotion automatically
        if (aiLocomotionReference != null)
            aiLocomotion = aiLocomotionReference;
        else
        {
            var aiComp = GetComponent<AiLocomotion>();
            if (aiComp != null) aiLocomotion = aiComp;
            else
            {
                // fallback: try to find any MonoBehaviour that looks like the AI (optional)
                // aiLocomotion = GetComponent<SomeOtherAiScript>(); // add if you have other AI types
                aiLocomotion = null;
            }
        }

        ragdollBodies = GetComponentsInChildren<Rigidbody>();

        // Start in animated state (bones kinematic)
        DeactivateRagdoll();
    }

    // Public method to activate ragdoll safely
    public void ActivateRagdoll()
    {
        // 1) Safely stop & disable NavMeshAgent if present
        if (agent != null)
        {
            if (agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }
            agent.enabled = false;
        }

        // 2) Disable animator so it no longer conflicts with ragdoll bones
        if (animator != null)
            animator.enabled = false;

        // 3) Disable AI locomotion script if we have one
        if (aiLocomotion != null)
            aiLocomotion.enabled = false;

        // 4) Enable physics on bones and zero velocities to avoid flinging
        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            rb.isKinematic = false;
            rb.useGravity = true;
        }

        // 5) Extra safety: zero velocities again on the next FixedUpdate to clear any impulses
        StartCoroutine(ZeroVelocitiesNextFixedUpdate());
    }

    // Optional: a safe way to deactivate ragdoll and restore animator/agent
    // Call this only if you intend to bring the character back from ragdoll to animated state.
    public void DeactivateRagdoll()
    {
        // Make all bones kinematic and clear velocities
        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.isKinematic = true;
            rb.useGravity = false;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Re-enable animator
        if (animator != null)
            animator.enabled = true;

        // Try to re-enable the NavMeshAgent only if there's a NavMesh nearby
        if (agent != null)
        {
            NavMeshHit hit;
            bool found = NavMesh.SamplePosition(transform.position, out hit, navMeshSampleDistance, NavMesh.AllAreas);
            if (found)
            {
                agent.enabled = true;
                agent.Warp(hit.position);
                agent.ResetPath();
                agent.isStopped = false;
            }
            else
            {
                agent.enabled = false;
#if UNITY_EDITOR
                Debug.LogWarning($"No NavMesh found near '{gameObject.name}'. NavMeshAgent remains disabled after ragdoll.");
#endif
            }
        }

        // Re-enable AI locomotion script if available
        if (aiLocomotion != null)
            aiLocomotion.enabled = true;
    }

    private IEnumerator ZeroVelocitiesNextFixedUpdate()
    {
        yield return new WaitForFixedUpdate();
        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }

    // Optional: activate ragdoll on player collision for quick testing
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            ActivateRagdoll();
        }
    }
}
