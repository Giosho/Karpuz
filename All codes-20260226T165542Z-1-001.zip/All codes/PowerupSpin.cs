using UnityEngine;

public class PowerupSpinHover : MonoBehaviour
{
    [Header("Rotation")]
    public float rotationSpeed = 100f;     // degrees per second

    [Header("Hover")]
    public float hoverHeight = 0.25f;      // how high it moves up/down
    public float hoverSpeed = 2f;          // how fast it floats

    private Vector3 startPos;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        // Spin horizontally
        transform.Rotate(0f, rotationSpeed * Time.deltaTime, 0f, Space.World);

        // Hover up and down
        float newY = startPos.y + Mathf.Sin(Time.time * hoverSpeed) * hoverHeight;
        transform.position = new Vector3(transform.position.x, newY, transform.position.z);
    }
}
