using System.Collections;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject enemyPrefab;
    public float spawnDelay = 1f;

    public void StartWave(int enemiesToSpawn)
    {
        StartCoroutine(SpawnEnemies(enemiesToSpawn));
    }

    IEnumerator SpawnEnemies(int count)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject go = Instantiate(enemyPrefab, transform.position, Quaternion.identity);

            // Register the spawned enemy with WaveManager
            if (WaveManager.Instance != null)
                WaveManager.Instance.OnEnemySpawned(go);

            yield return new WaitForSeconds(spawnDelay);
        }
    }
}
