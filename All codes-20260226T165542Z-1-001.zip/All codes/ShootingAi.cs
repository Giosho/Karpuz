using System.Collections.Generic;
using UnityEngine;

public class ShootingAii : MonoBehaviour
{
    [Header("Health")]
    public float health = 10f;
    private bool isDead = false;

    private RagdollTest ragdoll;

    [Header("Drop Settings")]
    public float dropOffsetY = 0.2f;

    [System.Serializable]
    public class DropEntry
    {
        public GameObject prefab;
        [Range(0f, 100f)]
        public float chance = 0f;
    }

    [Header("Drops")]
    public List<DropEntry> drops = new List<DropEntry>();

    [Header("Global Multiplier")]
    [Range(0f, 2f)]
    public float globalChanceMultiplier = 1f;

    private void Awake()
    {
        ragdoll = GetComponent<RagdollTest>();
        if (ragdoll == null)
            Debug.LogWarning("No RagdollTest found on " + gameObject.name);
    }

    public void TakeDamage(int damage)
    {
        AiLocomotion ai = GetComponent<AiLocomotion>();
        if (ai != null) ai.OnHit();

        if (isDead) return;

        health -= damage;
        if (health <= 0)
            Die();
    }

    private void Die()
    {
        if (isDead) return;
        isDead = true;

        // Notify WaveManager using the actual GameObject
        if (WaveManager.Instance != null)
            WaveManager.Instance.OnEnemyKilled(gameObject);

        // Ragdoll effect
        if (ragdoll != null)
            ragdoll.ActivateRagdoll();

        // Spawn drop
        SpawnDropWithAbsoluteChance();

        // Destroy enemy after delay (keep ragdoll visible)
        Destroy(gameObject, 3f);
    }

    private void SpawnDropWithAbsoluteChance()
    {
        if (drops == null || drops.Count == 0) return;

        float total = 0f;
        foreach (var d in drops)
        {
            if (d != null && d.prefab != null)
                total += Mathf.Clamp(d.chance, 0f, 100f) * globalChanceMultiplier;
        }
        if (total <= 0f) return;

        float scale = total > 100f ? 100f / total : 1f;
        float roll = Random.Range(0f, 100f);
        float accum = 0f;

        foreach (var d in drops)
        {
            if (d == null || d.prefab == null) continue;

            float effectiveChance = Mathf.Clamp(d.chance, 0f, 100f) * globalChanceMultiplier * scale;
            accum += effectiveChance;

            if (roll < accum)
            {
                Vector3 pos = transform.position + Vector3.up * dropOffsetY;
                Instantiate(d.prefab, pos, Quaternion.identity);
                return;
            }
        }
    }
}
