using System;
using UnityEngine;

[System.Serializable]
public class DoorPart
{
    public Transform part;

    [Header("Door 2 Offset (Split XYZ)")]
    public Vector3 door2Offset = new Vector3(0f, 0f, 1f);

    [Header("Door Sound")]
    public AudioClip doorSound; // Assign door.wav or big door.wav per part
}

[RequireComponent(typeof(AudioSource))]
public class DoorTrigger : MonoBehaviour
{
    [Header("Mode Selection")]
    public bool door1Mode; // Moves all parts down
    public bool door2Mode; // Uses custom XYZ for splitting

    [Header("Door Parts")]
    public DoorPart[] doorParts;

    [Header("Movement Settings")]
    public float door1MoveDistance = 3f; // vertical distance for Door 1
    public float moveSpeed = 2f;

    [Header("Optional Collider")]
    public Collider doorCollider;

    private Vector3[] startPositions;
    private Vector3[] targetPositions;
    private Vector3 colliderStartPos;
    private Vector3 colliderTargetPos;
    private bool activated = false;

    private AudioSource audioSource;
    private bool isPlaying = false;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.loop = true; // make the sound loop

        int count = doorParts.Length;
        startPositions = new Vector3[count];
        targetPositions = new Vector3[count];

        for (int i = 0; i < count; i++)
        {
            startPositions[i] = doorParts[i].part.position;
            Vector3 offset = Vector3.zero;

            if (door1Mode)
            {
                offset += Vector3.down * door1MoveDistance;
            }
            else if (door2Mode)
            {
                float dir = (i % 2 == 0) ? 1f : -1f;
                offset += Vector3.Scale(doorParts[i].door2Offset, new Vector3(1f, 1f, dir));
            }

            targetPositions[i] = startPositions[i] + offset;
        }

        if (doorCollider != null)
        {
            colliderStartPos = doorCollider.transform.position;
            colliderTargetPos = colliderStartPos;

            if (door1Mode)
                colliderTargetPos += Vector3.down * door1MoveDistance;
            else if (door2Mode)
                colliderTargetPos += doorParts[0].door2Offset;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
            activated = true;
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
            activated = false;
    }

    void Update()
    {
        bool isMoving = false;

        for (int i = 0; i < doorParts.Length; i++)
        {
            Vector3 destination = activated ? targetPositions[i] : startPositions[i];
            if (doorParts[i].part.position != destination)
            {
                isMoving = true;
                doorParts[i].part.position = Vector3.MoveTowards(
                    doorParts[i].part.position,
                    destination,
                    moveSpeed * Time.deltaTime
                );
            }
        }

        if (doorCollider != null)
        {
            Vector3 destination = activated ? colliderTargetPos : colliderStartPos;
            if (doorCollider.transform.position != destination)
            {
                isMoving = true;
                doorCollider.transform.position = Vector3.MoveTowards(
                    doorCollider.transform.position,
                    destination,
                    moveSpeed * Time.deltaTime
                );
            }
        }

        // Handle audio playback
        if (isMoving && !isPlaying)
        {
            // Play the first door's sound as representative
            if (doorParts.Length > 0 && doorParts[0].doorSound != null)
            {
                audioSource.clip = doorParts[0].doorSound;
                audioSource.Play();
                isPlaying = true;
            }
        }
        else if (!isMoving && isPlaying)
        {
            audioSource.Stop();
            isPlaying = false;
        }
    }
}
