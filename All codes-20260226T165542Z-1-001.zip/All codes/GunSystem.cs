using UnityEngine;
using TMPro;

public class GunSystem : MonoBehaviour
{
    //Gun stats
    public int damage;
    public float timeBetweenShooting, spread, range, reloadTime, timeBetweenShots;
    public int magazineSize, bulletsPerTap;
    public bool allowButtonHold;
    public int bulletsLeft, bulletsShot;
    [HideInInspector]
    public bool isAiming = false; // set from WeaponHandler

    //bools 
    [HideInInspector]
    public bool reloading;
    bool readyToShoot, shooting;

    //Reference
    public Camera fpsCam;
    public Transform attackPoint;
    public RaycastHit rayHit;
    public LayerMask whatIsEnemy;

    //Graphics
    public GameObject muzzleFlash, bulletHoleGraphic;
    public TextMeshProUGUI text;

    [Header("Reload UI")]
    [Tooltip("UI image or panel to show while reloading.")]
    public GameObject reloadUI;

    private void Awake()
    {
        bulletsLeft = magazineSize;
        readyToShoot = true;

        if (reloadUI != null)
            reloadUI.SetActive(false); // hide at start
    }

    private void Update()
    {
        MyInput();

        //SetText
        if (text != null)
            text.SetText(bulletsLeft + " / " + magazineSize);

        // Update reload UI visibility based on aiming state
        UpdateReloadUIVisibility();
    }

    private void MyInput()
    {
        if (allowButtonHold) shooting = Input.GetKey(KeyCode.Mouse0);
        else shooting = Input.GetKeyDown(KeyCode.Mouse0);

        if (Input.GetKeyDown(KeyCode.R) && bulletsLeft < magazineSize && !reloading)
            Reload();

        //Shoot only if ready, shooting, not reloading, has bullets, AND is aiming
        if (readyToShoot && shooting && !reloading && bulletsLeft > 0 && isAiming)
        {
            bulletsShot = bulletsPerTap;
            Shoot();
        }
    }

    private void Shoot()
    {
        if (bulletsLeft <= 0) return;

        readyToShoot = false;

        float x = Random.Range(-spread, spread);
        float y = Random.Range(-spread, spread);

        Vector3 direction = fpsCam.transform.forward + new Vector3(x, y, 0);

        if (Physics.Raycast(fpsCam.transform.position, direction, out rayHit, range, whatIsEnemy))
        {
            Debug.Log(rayHit.collider.name);

            if (rayHit.collider.CompareTag("Enemy"))
                rayHit.collider.GetComponent<ShootingAii>().TakeDamage(damage);

            if (bulletHoleGraphic != null)
                Instantiate(bulletHoleGraphic, rayHit.point, Quaternion.Euler(0, 180, 0));
        }

        if (muzzleFlash != null)
            Instantiate(muzzleFlash, attackPoint.position, Quaternion.identity);

        bulletsLeft--;
        bulletsShot--;

        Invoke("ResetShot", timeBetweenShooting);

        if (bulletsShot > 0 && bulletsLeft > 0)
            Invoke("Shoot", timeBetweenShots);
    }

    private void ResetShot()
    {
        readyToShoot = true;
    }

    private void Reload()
    {
        reloading = true;

        // UI visibility will be handled by UpdateReloadUIVisibility()
        Invoke("ReloadFinished", reloadTime);
    }

    private void ReloadFinished()
    {
        bulletsLeft = magazineSize;
        reloading = false;

        // UI visibility will be handled by UpdateReloadUIVisibility()
    }

    private void UpdateReloadUIVisibility()
    {
        if (reloadUI != null)
        {
            // Show reload UI only when reloading AND aiming
            bool shouldShowUI = reloading && isAiming;
            if (reloadUI.activeSelf != shouldShowUI)
            {
                reloadUI.SetActive(shouldShowUI);
            }
        }
    }
}