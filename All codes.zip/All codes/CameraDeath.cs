﻿using UnityEngine;

public class CameraDeath : MonoBehaviour
{
    [Header("Target Settings")]
    public Transform target;               // Player or ragdoll to follow
    public Vector3 offset = new Vector3(0, 2, -5); // Camera offset from target

    [Header("Follow Settings")]
    public float followSpeed = 5f;         // How fast the camera moves
    public float rotateSpeed = 5f;         // How fast the camera rotates to look at target

    private void LateUpdate()
    {
        if (target == null) return;

        // Desired camera position relative to target
        Vector3 desiredPosition = target.position + offset;

        // Smoothly move the camera to the desired position
        transform.position = Vector3.Lerp(transform.position, desiredPosition, followSpeed * Time.deltaTime);

        // Smoothly rotate the camera to look at the target
        Vector3 directionToTarget = target.position - transform.position;
        if (directionToTarget.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(directionToTarget);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotateSpeed * Time.deltaTime);
        }
    }

    /// <summary>
    /// Call this to change the camera's target dynamically (e.g., player dies → ragdoll)
    /// </summary>
    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }

}
