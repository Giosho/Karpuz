﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent), typeof(Animator))]
public class AiLocomotion : MonoBehaviour
{
    [Header("References")]
    public Transform player;
    public Animator animator;
    public Ragdoll ragdoll;

    [Header("Movement Speeds")]
    public float walkSpeed = 2f;
    public float runSpeed = 4f;

    [Header("Wandering Settings")]
    public float wanderRange = 10f;
    private Vector3 wanderTarget;

    [Header("Vision & Shooting Settings")]
    public float detectionRadius = 15f;
    [Range(0, 360)]
    public float fieldOfView = 120f;
    public LayerMask obstructionMask;
    public Transform firePoint;           // Muzzle or shooting point
    public GameObject bulletPrefab;       // Bullet prefab
    public float shootingRange = 5f;
    public float fireRate = 1f;           // bullets/sec
    public int bulletDamage = 10;         // damage per shot
    private float lastFireTime = 0f;
    private float alertDuration = 3f;
    private float alertTimer = 0f;
    public float alertedDetectionRadius = 100f; // radius to use when hit
    public float alertedDuration = 10f;         // how long to keep the big radius (set 0 to keep forever)
    private float originalDetectionRadius;

    [Header("Muzzle VFX & Sound (assign in Inspector)")]
    public ParticleSystem muzzleParticle;
    public AudioClip muzzleSfx;
    [Range(0f, 1f)]
    public float muzzleSfxVolume = 1f;

    [Header("Rotation")]
    public float rotationSpeed = 5f;

    [Header("Health Settings")]
    public int maxHealth = 100;
    private int currentHealth;

    private NavMeshAgent agent;
    private bool canSeePlayer = false;
    [HideInInspector]
    public bool isAlerted = false;
    private bool isDead = false;

    private void Awake()
    {
        currentHealth = maxHealth;
        originalDetectionRadius = detectionRadius;
    }

    public void TakeDamage(int amount)
    {
        currentHealth -= amount;
        OnHit();
        if (currentHealth <= 0)
            Die();
    }

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        if (!animator) animator = GetComponent<Animator>();

        if (!player)
        {
            GameObject p = GameObject.FindGameObjectWithTag("Player");
            if (p) player = p.transform;
        }

        PickNewWanderTarget();
        StartCoroutine(FOVRoutine());
    }

    private void Update()
    {
        if (isDead || agent == null) return;

        if (canSeePlayer || isAlerted)
        {
            float distance = Vector3.Distance(transform.position, player.position);

            if (distance <= shootingRange)
            {
                if (AgentReady())
                    agent.isStopped = true;      // safe now
                LookAtPlayer();
                Shoot();
            }
            else
            {
                if (AgentReady())
                    agent.isStopped = false;
                ChasePlayer();
            }
        }
        else
        {
            WanderBehaviour();
        }

        UpdateAnimations();
        RotateTowardsMovement();
    }


    private IEnumerator FOVRoutine()
    {
        WaitForSeconds wait = new WaitForSeconds(0.2f);
        while (!isDead)
        {
            yield return wait;
            UpdateFieldOfView();
        }
    }

    private void UpdateFieldOfView()
    {
        if (!player) { canSeePlayer = false; return; }

        Vector3 dirToPlayer = player.position - transform.position;
        float distance = dirToPlayer.magnitude;

        bool seesPlayerNow = false;

        if (distance <= 2f) seesPlayerNow = true;
        else if (distance <= detectionRadius)
        {
            float angle = Vector3.Angle(transform.forward, dirToPlayer);
            if (angle <= fieldOfView / 2f)
            {
                if (!Physics.Raycast(transform.position + Vector3.up * 1.5f, dirToPlayer.normalized, distance, obstructionMask))
                {
                    seesPlayerNow = true;
                }
            }
        }

        canSeePlayer = seesPlayerNow;

        if (seesPlayerNow)
        {
            isAlerted = true;
            alertTimer = Time.time + alertDuration;
        }
        else if (Time.time > alertTimer)
        {
            isAlerted = false;
        }
    }
    public void OnHit()
    {
        // Expand detection radius and force alert
        detectionRadius = alertedDetectionRadius;
        isAlerted = true;
        canSeePlayer = true;
        alertTimer = Time.time + alertDuration;

        // If you want the radius to revert automatically after a while:
        if (alertedDuration > 0f)
        {
            StopAllCoroutines(); // optional, to avoid multiple coroutines stacking
            StartCoroutine(RevertDetectionRadiusAfterDelay(alertedDuration));
        }
    }
    private IEnumerator RevertDetectionRadiusAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        detectionRadius = originalDetectionRadius;
    }
    private void ChasePlayer()
    {
        if (AgentReady())
        {
            agent.speed = runSpeed;
            agent.SetDestination(player.position);
        }
    }

    private void WanderBehaviour()
    {
        if (AgentReady())
        {
            agent.speed = walkSpeed;

            if (agent.remainingDistance <= agent.stoppingDistance)
                PickNewWanderTarget();

            agent.SetDestination(wanderTarget);
        }
    }

    private void PickNewWanderTarget()
    {
        Vector3 randomDir = Random.insideUnitSphere * wanderRange + transform.position;
        NavMeshHit hit;
        if (NavMesh.SamplePosition(randomDir, out hit, 2f, NavMesh.AllAreas))
            wanderTarget = hit.position;
    }

    private void LookAtPlayer()
    {
        Vector3 direction = (player.position - transform.position).normalized;

        // Add a slight offset to the right
        Vector3 rightOffset = transform.right * 0.5f; // adjust 0.5f to make the turn more or less
        direction += rightOffset;
        direction.y = 0;

        if (direction.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
    }


    private void Shoot()
    {
        if (Time.time - lastFireTime < 1f / fireRate) return;
        lastFireTime = Time.time;

        if (firePoint == null || player == null) return;

        Vector3 dir = (player.position - firePoint.position).normalized;
        float maxRange = shootingRange; // or compute distance to player

        // Raycast against ALL layers (or a mask that includes player and environment).
        // We'll use a mask that includes the player layer + environment so the ray will hit the first thing.
        int mask = ~0; // all layers (or set a mask that includes player & obstacles)

        if (Physics.Raycast(firePoint.position, dir, out RaycastHit hit, maxRange, mask))
        {
            // Did the ray hit the player?
            PlayerHealth ph = hit.collider.GetComponentInParent<PlayerHealth>();
            if (ph != null)
            {
                // Hit the player directly — apply damage
                ph.TakeDamage(bulletDamage);
            }
            else
            {
                // Hit something else (wall) — do nothing (blocked)
            }
        }

        // visual effects only (muzzle + tracer)
        animator.SetBool("isShooting", true);
        if (muzzleParticle != null)
        {
            muzzleParticle.transform.position = firePoint.position;
            muzzleParticle.transform.rotation = firePoint.rotation;
            muzzleParticle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            muzzleParticle.Play(true);
        }
        if (muzzleSfx != null)
        {
            AudioSource.PlayClipAtPoint(muzzleSfx, firePoint.position, muzzleSfxVolume);
        }
    }
    private bool AgentReady()
    {
        return agent != null && agent.enabled && agent.isOnNavMesh;
    }


    private void UpdateAnimations()
    {
        float speed = agent.velocity.magnitude;
        bool isShooting = canSeePlayer && Vector3.Distance(transform.position, player.position) <= shootingRange;

        animator.SetBool("isWalking", !isShooting && !canSeePlayer && speed > 0.1f && agent.speed == walkSpeed);
        animator.SetBool("isRunning", !isShooting && canSeePlayer && speed > 0.1f);
        animator.SetBool("isShooting", isShooting);
    }

    private void RotateTowardsMovement()
    {
        Vector3 velocity = Vector3.zero;
        if (AgentReady()) velocity = agent.velocity;

        if (velocity.magnitude > 0.1f)
        {
            Vector3 lookDir = velocity.normalized;
            lookDir.y = 0;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(lookDir), rotationSpeed * Time.deltaTime);
        }
    }


    public void Die()
    {
        if (isDead) return;
        isDead = true;

        // Try to stop & clear agent safely
        if (agent != null)
        {
            if (agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }
            // disable the agent so it no longer affects transforms/colliders
            agent.enabled = false;
        }

        // Disable animator so bones are no longer driven by the animator
        if (animator != null)
            animator.enabled = false;

        // Activate ragdoll (assumes your ragdoll.ActivateRagdoll properly turns on rigidbodies)
        if (ragdoll != null)
        {
            ragdoll.ActivateRagdoll();
            // zero velocities next physics step to avoid impulse "flinging"
            StartCoroutine(ZeroRagdollVelocitiesNextFixedFrame());
        }

        // Notify wave manager (keep this)
        if (WaveManager.Instance != null)
            WaveManager.Instance.OnEnemyKilled();

        // Destroy after a delay so ragdoll persists
        Destroy(gameObject, 3f);
    }
    private System.Collections.IEnumerator ZeroRagdollVelocitiesNextFixedFrame()
    {
        // Wait for the next FixedUpdate so ragdoll rigidbodies are initialized/activated
        yield return new WaitForFixedUpdate();

        if (ragdoll == null) yield break;

        // Assuming your ragdoll script makes rigidbodies non-kinematic and activates colliders,
        // grab them and zero their velocity and angular velocity to avoid "flying"
        Rigidbody[] rbs = ragdoll.GetComponentsInChildren<Rigidbody>();
        foreach (var rb in rbs)
        {
            if (rb != null)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }
    }

}
