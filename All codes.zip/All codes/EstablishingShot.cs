using System.Collections;
using System.Reflection;
using Cinemachine;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif
using UnityEngine.UI;

public class EstablishingShot : MonoBehaviour
{
    [Header("Camera References (Cinemachine)")]
    public CinemachineVirtualCamera establishingCam; // sun shot
    public CinemachineVirtualCamera playerCam;       // player follow camera

    [Header("Timing")]
    public float establishingShotDuration = 3f;

    [Header("Optional: Player input/components to disable during intro")]
#if ENABLE_INPUT_SYSTEM
    public PlayerInput playerInput;
#endif
    public MonoBehaviour playerController;  // your movement script
    public MonoBehaviour mouseLookScript;   // your look script

    [Header("Optional: UI Canvas to disable during intro")]
    public Canvas uiCanvas;

    [Header("Audio (music)")]
    public AudioSource musicSource;
    public AudioClip musicClip;
    [Range(0f, 1f)]
    public float musicVolume = 1f;
    public bool loopMusic = true;
    public float musicFadeInDuration = 1f;

    [Header("Optional: Black overlay to hide low-res preload flicker")]
    public Image blackPanel; // assign a fullscreen black UI Image

    [Header("Player Health Reference")]
    public PlayerHealth playerHealth; // assign your player health

    private CursorLockMode prevLock;
    private bool prevVisible;

    void Start()
    {
        if (establishingCam == null || playerCam == null)
            return;

        prevLock = Cursor.lockState;
        prevVisible = Cursor.visible;

        if (blackPanel != null)
            blackPanel.gameObject.SetActive(true);

        if (uiCanvas != null)
            uiCanvas.enabled = false;

        if (Camera.main != null && Camera.main.targetTexture != null)
            Camera.main.Render();

        StartCoroutine(StartSequenceAfterPreload());
    }

    IEnumerator StartSequenceAfterPreload()
    {
        yield return null;
        if (blackPanel != null)
            blackPanel.gameObject.SetActive(false);
        SetupStartCameras();
        yield return StartCoroutine(PlayEstablishingShot());
    }

    void SetupStartCameras()
    {
        establishingCam.Priority = 100;
        playerCam.Priority = 0;
        establishingCam.gameObject.SetActive(true);
        playerCam.gameObject.SetActive(false);
    }

    void PrepareAudioSource()
    {
        if (musicSource == null)
        {
            musicSource = gameObject.AddComponent<AudioSource>();
            musicSource.playOnAwake = false;
        }
        musicSource.loop = loopMusic;
        musicSource.volume = musicVolume;
    }

    IEnumerator PlayEstablishingShot()
    {
        DisablePlayerInput(true);
        yield return new WaitForSeconds(establishingShotDuration);
        establishingCam.gameObject.SetActive(false);
        playerCam.gameObject.SetActive(true);
        establishingCam.Priority = 0;
        playerCam.Priority = 100;

        if (uiCanvas != null)
            uiCanvas.enabled = true;

        DisablePlayerInput(false);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        StartMusic();
    }

    public void StartMusic()
    {
        if (musicClip == null)
        {
            Debug.LogWarning("No musicClip assigned to EstablishingShot script.");
            return;
        }

        if (musicSource == null)
            PrepareAudioSource();

        musicSource.clip = musicClip;
        musicSource.loop = loopMusic;
        musicSource.Play();

        if (musicFadeInDuration > 0f)
            StartCoroutine(FadeMusicToVolume(musicVolume, musicFadeInDuration));
        else
            musicSource.volume = musicVolume;
    }

    void Update()
    {
        // Adjust music volume dynamically based on slider or variable
        if (musicSource != null && musicSource.isPlaying)
        {
            musicSource.volume = musicVolume;

            // Stop music if player is dead
            if (playerHealth != null && playerHealth.isDead)
                musicSource.Stop();
        }
    }

    IEnumerator FadeMusicToVolume(float targetVolume, float duration)
    {
        if (musicSource == null)
            yield break;

        float start = musicSource.volume;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            musicSource.volume = Mathf.Lerp(start, targetVolume, Mathf.Clamp01(elapsed / duration));
            yield return null;
        }
        musicSource.volume = targetVolume;
    }

    void DisablePlayerInput(bool disable)
    {
#if ENABLE_INPUT_SYSTEM
        if (playerInput != null)
            playerInput.enabled = !disable;
#endif
        if (playerController != null)
        {
            MethodInfo mi = playerController.GetType().GetMethod("SetInputEnabled", BindingFlags.Public | BindingFlags.Instance);
            if (mi != null)
                mi.Invoke(playerController, new object[] { !disable });
            else
                playerController.enabled = !disable;
        }
        if (mouseLookScript != null)
            mouseLookScript.enabled = !disable;
    }

    public void PauseMusic()
    {
        if (musicSource != null && musicSource.isPlaying)
            musicSource.Pause();
    }

    public void ResumeMusic()
    {
        if (musicSource != null && !musicSource.isPlaying && (playerHealth == null || !playerHealth.isDead))
            musicSource.UnPause();
    }
}