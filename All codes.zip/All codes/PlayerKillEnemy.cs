using UnityEngine;

public class PlayerKillEnemy : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // Enemy AI script might be on parent
        AiLocomotion enemyAI = other.GetComponentInParent<AiLocomotion>();

        if (enemyAI != null)
        {
            enemyAI.Die();
        }
    }
}
