using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health Settings")]
    public int maxHealth = 100;
    private int currentHealth;

    [Header("Death Camera")]
    public GameObject deathCamera;

    [Header("Player Controller")]
    public MonoBehaviour controllerScript;

    [Header("Custom Enable/Disable Lists")]
    public GameObject[] objectsToDisableOnDeath;
    public GameObject[] objectsToEnableOnDeath;

    [HideInInspector]
    public bool isDead = false;

    [Header("UI")]
    public TextMeshProUGUI HP;
    public GameObject deathScreenUI; // assign your death screen panel here

    [Header("Invincibility")]
    public bool isInvincible = false;
    private float invincibleTimer = 0f;
    public GameObject invincibilityUI;

    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip[] damageSounds;
    public AudioClip deathSound;
    [Range(0f, 1f)]
    public float damageSoundChance = 0.5f;

    private void Start()
    {
        currentHealth = maxHealth;
        if (HP != null)
            HP.SetText($"{currentHealth} HP");

        if (deathCamera)
            deathCamera.SetActive(false);

        if (invincibilityUI != null)
            invincibilityUI.SetActive(false);

        if (deathScreenUI != null)
            deathScreenUI.SetActive(false); // hide death screen at start
    }

    private void Update()
    {
        if (isDead) return;

        if (isInvincible)
        {
            invincibleTimer -= Time.deltaTime;
            if (invincibleTimer <= 0f)
            {
                isInvincible = false;
                invincibleTimer = 0f;
                if (invincibilityUI != null)
                    invincibilityUI.SetActive(false);
            }
        }
    }

    public void TakeDamage(int amount)
    {
        if (isDead) return;

        if (isInvincible)
        {
            Debug.Log("Blocked damage � player is invincible");
            return;
        }

        currentHealth -= amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        if (HP != null)
            HP.SetText($"{currentHealth} HP");

        // Play damage sound randomly if not dead
        if (!isDead && audioSource != null && damageSounds.Length > 0 && Random.value < damageSoundChance)
        {
            AudioClip clip = damageSounds[Random.Range(0, damageSounds.Length)];
            audioSource.Stop();
            audioSource.clip = clip;
            audioSource.Play();
        }

        if (currentHealth <= 0)
            Die();
    }

    public void ActivateInvincibility(float duration)
    {
        if (duration <= 0f) return;

        isInvincible = true;
        invincibleTimer = duration;

        if (invincibilityUI != null)
            invincibilityUI.SetActive(true);
    }

    public void Heal(int amount)
    {
        if (isDead) return;
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        if (HP != null)
            HP.SetText($"{currentHealth} HP");
    }

    private void Die()
    {
        if (isDead) return;
        isDead = true;

        if (HP != null)
            HP.SetText($"Died");

        foreach (GameObject obj in objectsToDisableOnDeath)
            if (obj != null)
                obj.SetActive(false);

        if (controllerScript)
            controllerScript.enabled = false;

        foreach (GameObject obj in objectsToEnableOnDeath)
            if (obj != null)
                obj.SetActive(true);

        if (invincibilityUI != null)
            invincibilityUI.SetActive(false);

        if (deathCamera)
            deathCamera.SetActive(true);

        if (deathScreenUI != null)
            deathScreenUI.SetActive(true); // show death screen

        // Pause the game
        Time.timeScale = 0f;

        // Play death sound
        if (audioSource != null && deathSound != null)
        {
            audioSource.Stop();
            audioSource.clip = deathSound;
            audioSource.Play();
        }
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
    }

    // Optional: call this from a button on the death screen to restart
    public void RestartGame()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }
}
