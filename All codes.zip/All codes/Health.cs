using UnityEngine;
using UnityEngine.AI; // Make sure to include this

public class Health : MonoBehaviour
{
    public float maxHealth;
    public float currentHealth;

    Ragdoll ragdoll;
    NavMeshAgent agent;

    void Start()
    {
        ragdoll = GetComponent<Ragdoll>();
        agent = GetComponent<NavMeshAgent>();
        currentHealth = maxHealth;
    }

    public void TakeDamage(float amount)
    {
        currentHealth -= amount;
        if (currentHealth <= 0.0f)
        {
            Die();
        }
    }

    private void Die()
    {
        // Stop NavMeshAgent so it doesn't move
        if (agent != null)
            agent.enabled = false;

        // Activate ragdoll
        ragdoll.ActivateRagdoll();
    }
}
