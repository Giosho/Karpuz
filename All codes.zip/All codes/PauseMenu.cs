using UnityEngine;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseUI;
    public KeyCode pauseKey = KeyCode.Escape;

    public static bool IsPaused = false;

    // Reference to your EstablishingShot script that manages music
    public EstablishingShot audioManager;

    void Update()
    {
        if (Input.GetKeyDown(pauseKey))
        {
            if (IsPaused) Resume();
            else Pause();
        }
    }

    public void Pause()
    {
        Debug.Log("PAUSED");

        pauseUI.SetActive(true);
        Time.timeScale = 0f;
        IsPaused = true;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // Pause music
        if (audioManager != null)
            audioManager.PauseMusic();
    }

    public void Resume()
    {
        Debug.Log("Resi=med");

        pauseUI.SetActive(false);
        Time.timeScale = 1f;
        IsPaused = false;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // Resume music
        if (audioManager != null)
            audioManager.ResumeMusic();
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit Game");
    }
}
