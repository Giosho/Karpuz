using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class WaveManager : MonoBehaviour
{
    // Singleton
    public static WaveManager Instance { get; private set; }

    [Header("Wave settings")]
    public int baseEnemiesPerWave = 5;
    [Tooltip("Enemies scale per wave: total = base * waveMultiplier^(wave-1)")]
    public float waveMultiplier = 1.5f;
    public float timeBetweenWaves = 5f;
    public float maxWaveDuration = 60f; // if a wave runs longer than this, it's considered timed out

    [Header("Spawners")]
    [Tooltip("Assign your spawner GameObjects here. Spawners can implement StartWave(int) or StartWaveSpawn(int).")]
    public GameObject[] spawners; // use GameObject[] so we can SendMessage for compatibility

    [Header("Debug")]
    public int currentWave = 1;

    // internal state (replaces old single-counter model)
    private int totalEnemiesThisWave = 0;      // how many we expect this wave
    private int spawnedCount = 0;              // how many have actually been spawned (registered)
    private int killedCount = 0;               // how many kills we have registered
    private HashSet<int> aliveEnemyIds = new(); // instanceIDs of currently alive enemies for this wave

    private bool waveInProgress = false;
    private float waveStartTime = 0f;

    // UI
    public TextMeshProUGUI wave;
    public TextMeshProUGUI enemiesR;

    private void Awake()
    {
        // Basic singleton pattern
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        UpdateWaveUI();
        UpdateEnemiesUI();
    }

    private void Start()
    {
        // start the first wave after a small delay
        StartCoroutine(StartWaveAfterDelay(timeBetweenWaves));
    }

    IEnumerator StartWaveAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        StartWave();
    }

    public void StartWave()
    {
        // compute total enemies for this wave (rounded up, min 1)
        totalEnemiesThisWave = Mathf.Max(1, Mathf.CeilToInt(baseEnemiesPerWave * Mathf.Pow(waveMultiplier, Mathf.Max(0, currentWave - 1))));
        spawnedCount = 0;
        killedCount = 0;
        aliveEnemyIds.Clear();

        waveInProgress = true;
        waveStartTime = Time.time;

        // update bookkeeping UI
        UpdateEnemiesUI(); // will show 0 alive until spawners register
        UpdateWaveUI();

        // distribute fairly among spawners
        int spawnerCount = Mathf.Max(1, spawners != null ? spawners.Length : 0);
        int basePerSpawner = totalEnemiesThisWave / spawnerCount;
        int remainder = totalEnemiesThisWave % spawnerCount;

        for (int i = 0; i < spawnerCount; i++)
        {
            int toSpawn = basePerSpawner + (i < remainder ? 1 : 0);

            if (spawners[i] == null) continue;

            // Try to call either StartWave(int) or StartWaveSpawn(int) on the spawner for compatibility
            spawners[i].SendMessage("StartWave", toSpawn, SendMessageOptions.DontRequireReceiver);
            spawners[i].SendMessage("StartWaveSpawn", toSpawn, SendMessageOptions.DontRequireReceiver);
        }

        Debug.Log($"Wave {currentWave} started. Expecting {totalEnemiesThisWave} enemies total across {spawnerCount} spawners.");
        currentWave++;
        UpdateWaveUI();

        // start a small coroutine to watch for timeout and keep alive
        StartCoroutine(WaveWatcher());
    }

    IEnumerator WaveWatcher()
    {
        while (waveInProgress)
        {
            // optional debug logging:
            // Debug.Log($"WaveWatcher: spawned {spawnedCount}/{totalEnemiesThisWave}, alive {aliveEnemyIds.Count}, killed {killedCount}");
            yield return new WaitForSeconds(0.5f);

            if (Time.time - waveStartTime > maxWaveDuration)
            {
                Debug.LogWarning("Wave timed out (maxWaveDuration).");
                // We don't forcibly end the wave here � enemies can check IsWaveTimedOut() to glow.
            }
        }
    }

    /// <summary>
    /// Recommended: call this from your Spawner immediately after Instantiate, passing the spawned GameObject.
    /// Example in Spawner: WaveManager.Instance.OnEnemySpawned(go);
    /// </summary>
    public void OnEnemySpawned(GameObject enemy)
    {
        if (!waveInProgress)
        {
            Debug.LogWarning("OnEnemySpawned called while no wave in progress. Ignoring registration.");
            return;
        }

        if (enemy == null) return;

        int id = enemy.GetInstanceID();
        if (aliveEnemyIds.Contains(id)) return; // already registered

        aliveEnemyIds.Add(id);
        spawnedCount++;

        UpdateEnemiesUI();

        Debug.Log($"OnEnemySpawned: id={id}, spawnedCount={spawnedCount}/{totalEnemiesThisWave}, alive={aliveEnemyIds.Count}");
    }

    // Backwards-compatible no-arg spawn register (less precise)
    public void OnEnemySpawned()
    {
        spawnedCount++;
        UpdateEnemiesUI();
        Debug.Log($"OnEnemySpawned (no-arg). spawnedCount={spawnedCount}");
    }

    /// <summary>
    /// Recommended: enemies call this with the exact GameObject that died (before Destroy).
    /// </summary>
    public void OnEnemyKilled(GameObject enemy)
    {
        if (enemy == null)
        {
            Debug.LogWarning("OnEnemyKilled called with null GameObject. Use no-arg if you cannot pass the reference.");
            return;
        }

        int id = enemy.GetInstanceID();

        if (!aliveEnemyIds.Contains(id))
        {
            // already removed or never registered
            Debug.Log($"OnEnemyKilled: id={id} was not in alive set (already removed or not registered). Ignoring duplicate.");
            return;
        }

        aliveEnemyIds.Remove(id);
        killedCount++;

        UpdateEnemiesUI();

        Debug.Log($"OnEnemyKilled: id={id}. killedCount={killedCount}, aliveRemaining={aliveEnemyIds.Count}.");

        // If we've killed all expected enemies and no alive ones remain -> end wave.
        if (killedCount >= totalEnemiesThisWave && aliveEnemyIds.Count == 0)
        {
            StartCoroutine(EndWaveAfterDelay(0.15f));
        }
        else
        {
            // Extra safety: if we have no alive registered enemies and spawned >= expected and killed >= spawned
            if (aliveEnemyIds.Count == 0 && spawnedCount >= totalEnemiesThisWave && killedCount >= spawnedCount)
            {
                StartCoroutine(EndWaveAfterDelay(0.15f));
            }
        }
    }

    // Backwards-compatible no-arg kill (less robust)
    public void OnEnemyKilled()
    {
        killedCount++;
        Debug.Log($"OnEnemyKilled(no-arg). killedCount={killedCount}, spawnedCount={spawnedCount}, aliveKnown={aliveEnemyIds.Count}");

        if (killedCount >= totalEnemiesThisWave && aliveEnemyIds.Count == 0)
        {
            StartCoroutine(EndWaveAfterDelay(0.15f));
        }
    }

    IEnumerator EndWaveAfterDelay(float delay)
    {
        // small safety delay to let any last Destroy/OnDeath events settle
        yield return new WaitForSeconds(delay);

        // Final sanity check before actually ending:
        if (aliveEnemyIds.Count > 0)
        {
            Debug.Log("EndWave aborted: there are still alive tracked enemies.");
            yield break;
        }

        waveInProgress = false;
        Debug.Log("Wave complete. Scheduling next wave...");
        StartCoroutine(StartWaveAfterDelay(timeBetweenWaves));
    }

    public int GetEnemiesRemaining()
    {
        if (waveInProgress) return aliveEnemyIds.Count;
        return 0;
    }

    public bool IsWaveTimedOut()
    {
        return waveInProgress && (Time.time - waveStartTime >= maxWaveDuration);
    }

    public bool IsWaveInProgress() => waveInProgress;

    // UI helpers (safe to call even if text fields are not assigned)
    private void UpdateWaveUI()
    {
        if (wave != null)
        {
            // show the wave that is currently running (currentWave was incremented after StartWave)
            wave.SetText($"wave: {Mathf.Max(1, currentWave - (waveInProgress ? 1 : 0))}");
        }
    }

    private void UpdateEnemiesUI()
    {
        if (enemiesR != null)
        {
            // show the number of alive tracked enemies if a wave is in progress,
            // otherwise show 0 or the expected total for clarity
            int display = waveInProgress ? aliveEnemyIds.Count : 0;
            enemiesR.SetText($"Enemies remaining: {display}");
        }
    }
}
