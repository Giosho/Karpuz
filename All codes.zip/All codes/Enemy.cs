using UnityEngine;

public class Enemy : MonoBehaviour
{
    private Renderer rend;
    private Color originalColor;
    public Color glowColor = Color.yellow;

    void Start()
    {
        rend = GetComponent<Renderer>();
        originalColor = rend.material.color;
    }

    void Update()
    {
        int aliveEnemies = FindObjectsOfType<Enemy>().Length;

        if (aliveEnemies <= 5)
        {
            Glow(true);
        }
    }

    public void Glow(bool on)
    {
        rend.material.color = on ? glowColor : originalColor;
    }
}
