using UnityEngine;
using StarterAssets;
using UnityEngine.Animations.Rigging;
using Cinemachine;
using System.Collections;

public class WeaponHandler : MonoBehaviour
{
    [Header("References")]
    private Animator anim;
    private ThirdPersonController controller;
    [SerializeField] private CinemachineVirtualCamera vcam;
    private Cinemachine3rdPersonFollow cmFollow;
    [SerializeField] private GunSystem gunSystem; // assign in Inspector


    [Header("Shooting")]
    [SerializeField] private float fireRate = 0.09f;
    [SerializeField] private float shootBlendTime = 0.075f;
    [SerializeField] private string shootStateName = "Fire_Rifle";
    [SerializeField] private AudioClip shootSound;
    [SerializeField] private ParticleSystem muzzleFlash;
    private bool canShoot = true;

    [Header("Aiming")]
    [SerializeField] private float cameraTransitionSpeed = 7f;
    [SerializeField] private float ikTransitionSpeed = 10f;
    [SerializeField] private MultiAimConstraint aimIk;
    [Space(10)]
    [SerializeField] private float aimVerticalArmLength = 0.2f;
    [SerializeField] private float aimCameraSide = 0.75f;
    [SerializeField] private float aimCameraDistance = 2.0f;

    [Header("Aiming - Offset")]
    [SerializeField] private Transform aimTarget;           // assign this in Inspector (the IK target transform)
    [SerializeField] private float aimYawOffset = 15f;     // degrees: positive -> aim more right; tweak to taste
    [SerializeField] private float aimTargetSmoothing = 10f; // smoothing factor used in Mathf.LerpAngle

    [Header("UI")]
    [SerializeField] private GameObject crosshair;



    // VARIABLES
    private bool Aiming;
    private float defaultVerticalArmLength;
    private float defaultCameraSide;
    private float defaultCameraDistance;

    // store default yaw so we can restore it when not aiming
    private float defaultAimYawOffset;

    // cache original aimTarget local rotation so it won't be altered when not aiming
    private Quaternion defaultAimTargetLocalRotation;
    private bool hasCachedAimTargetRotation = false;

    // restore coroutine control
    private Coroutine restoreCoroutine = null;
    [SerializeField][Tooltip("How long (s) to smoothly restore aimTarget localRotation when you stop aiming.")]
    private float restoreDuration = 0.12f;

    // thresholds for movement detection
    private const float sidewaysThreshold = 0.1f;
    private const float forwardThreshold = 0.1f;

    // track previous aiming state to detect transitions
    private bool prevAiming = false;

    private void Start()
    {
        anim = GetComponent<Animator>();
        controller = GetComponent<ThirdPersonController>();

        // GET CAMERA FOLLOW COMPONENT
        cmFollow = vcam.GetCinemachineComponent<Cinemachine3rdPersonFollow>();

        // STORE DEFAULT CAMERA VALUES
        defaultVerticalArmLength = cmFollow.VerticalArmLength;
        defaultCameraSide = cmFollow.CameraSide;
        defaultCameraDistance = cmFollow.CameraDistance;

        // store the initial aim yaw offset so we can reset it later
        defaultAimYawOffset = aimYawOffset;

        // cache aimTarget's initial local rotation so we can restore it while not aiming
        if (aimTarget != null)
        {
            defaultAimTargetLocalRotation = aimTarget.localRotation;
            hasCachedAimTargetRotation = true;
        }
    }

    private void Update()
    {
        // INPUT
        bool holdingFire2 = Input.GetButton("Fire2");
        bool shootInp = Input.GetButton("Fire1");

        // ANIMATIONS
        Aiming = holdingFire2;
        anim.SetBool("Aiming", Aiming);
        controller.Strafe = true;


        // CAMERA VALUES
        float targetVerticalArmLength = Aiming ? aimVerticalArmLength : defaultVerticalArmLength;
        float targetSide = Aiming ? aimCameraSide : defaultCameraSide;
        float targetDistance = Aiming ? aimCameraDistance : defaultCameraDistance;

        // CAMERA LERPING
        cmFollow.VerticalArmLength = Mathf.Lerp(cmFollow.VerticalArmLength, targetVerticalArmLength, cameraTransitionSpeed * Time.deltaTime);
        cmFollow.CameraSide = Mathf.Lerp(cmFollow.CameraSide, targetSide, cameraTransitionSpeed * Time.deltaTime);
        cmFollow.CameraDistance = Mathf.Lerp(cmFollow.CameraDistance, targetDistance, cameraTransitionSpeed * Time.deltaTime);

        // UI
        crosshair.SetActive(Aiming);

        // ---------------------
        // Only run aim/offset/aimTarget rotation while holding right-click
        // ---------------------
        if (holdingFire2)
        {
            // If we were restoring rotation, stop it because player started aiming again
            if (restoreCoroutine != null)
            {
                StopCoroutine(restoreCoroutine);
                restoreCoroutine = null;
            }

            // read horizontal and vertical axes
            float horizontal = Input.GetAxis("Horizontal"); // A/D or left/right
            float vertical = Input.GetAxis("Vertical");     // W/S or forward/back

            bool movingHoriz = Mathf.Abs(horizontal) > sidewaysThreshold;
            bool movingVert = Mathf.Abs(vertical) > forwardThreshold;

            // Determine movement state:
            bool onlySideways = movingHoriz && !movingVert;
            bool onlyForward = movingVert && !movingHoriz;
            bool bothDirections = movingHoriz && movingVert;

            // apply aim yaw offset rules when holding right-click
            if (onlySideways)
            {
                aimYawOffset = 0f;   // only strafing -> 0 degrees
            }
            else if (onlyForward)
            {
                aimYawOffset = 47f;  // only forward/back -> 40 degrees
            }
            else if (bothDirections)
            {
                aimYawOffset = 20f;  // both directions -> 20 degrees
            }
            else
            {
                // not moving (standing still)
                aimYawOffset = 47f;  // standing still -> treat like forward/back
            }

            // Smoothly rotate aimTarget toward desired yaw (if assigned)
            if (aimTarget != null)
            {
                Transform camTarget = controller.CinemachineCameraTarget != null
                                      ? controller.CinemachineCameraTarget.transform
                                      : null;

                // fallback: use virtual camera's follow target (if available)
                if (camTarget == null && vcam.Follow != null)
                    camTarget = ((Transform)vcam.Follow);

                if (camTarget != null)
                {
                    float cameraYaw = camTarget.eulerAngles.y;
                    float desiredYaw = cameraYaw + aimYawOffset;

                    Vector3 currentEuler = aimTarget.eulerAngles;
                    float currentYaw = currentEuler.y;

                    // smooth yaw using LerpAngle (preserves smooth behavior)
                    float newYaw = Mathf.LerpAngle(currentYaw, desiredYaw, Mathf.Clamp01(aimTargetSmoothing * Time.deltaTime));
                    aimTarget.rotation = Quaternion.Euler(currentEuler.x, newYaw, currentEuler.z);
                }
            }

            // Smoothly lerp IK weight toward 1 while aiming
            if (aimIk != null)
                aimIk.weight = Mathf.Lerp(aimIk.weight, 1f, ikTransitionSpeed * Time.deltaTime);
        }
        else
        {
            // Transition detection: if we JUST stopped aiming, immediately disable IK and restore aimTarget
            if (prevAiming && !Aiming)
            {
                // disable IK immediately
                if (aimIk != null)
                    aimIk.weight = 0f;

                // start restoring aimTarget local rotation if we have a cached value
                if (aimTarget != null && hasCachedAimTargetRotation)
                {
                    // if a previous restore coroutine is running, stop it first
                    if (restoreCoroutine != null)
                        StopCoroutine(restoreCoroutine);

                    restoreCoroutine = StartCoroutine(RestoreAimTargetLocalRotationCoroutine(restoreDuration));
                }
            }

            // Not aiming: DO NOT otherwise modify aimTarget transform here so animation/walk logic controls bones.
            // Restore yaw offset to default so other systems reading it get a sensible value.
            aimYawOffset = defaultAimYawOffset;

            // Also, if not in the middle of restoring, ensure IK remains off (safety)
            if (restoreCoroutine == null && aimIk != null)
                aimIk.weight = 0f;
        }

        // SHOOTING
        if (shootInp && Aiming)
        {
            Shoot();
        }
        // Set aiming state for GunSystem
        if (gunSystem != null)
        {
            gunSystem.isAiming = Aiming;
        }


        // store previous aiming state for next frame transition checks
        prevAiming = Aiming;
    }

    private IEnumerator RestoreAimTargetLocalRotationCoroutine(float duration)
    {
        if (aimTarget == null || !hasCachedAimTargetRotation)
        {
            restoreCoroutine = null;
            yield break;
        }

        Quaternion startRot = aimTarget.localRotation;
        Quaternion endRot = defaultAimTargetLocalRotation;

        if (duration <= 0.0001f)
        {
            aimTarget.localRotation = endRot;
            restoreCoroutine = null;
            yield break;
        }

        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            aimTarget.localRotation = Quaternion.Slerp(startRot, endRot, t);
            yield return null;
        }

        aimTarget.localRotation = endRot;
        restoreCoroutine = null;
    }

    private void Shoot()
    {
        if (!canShoot || gunSystem == null || gunSystem.bulletsLeft <= 0 || gunSystem.reloading == true)
            return; // stop if out of ammo

        // Consume ammo via GunSystem
       

        // Play effects
        AudioSource.PlayClipAtPoint(shootSound, transform.position);
        if (muzzleFlash != null)
            muzzleFlash.Play();

        anim.CrossFadeInFixedTime(shootStateName, shootBlendTime);

        StartCoroutine(ResetFireRate());
    }


    private IEnumerator ResetFireRate()
    {
        canShoot = false;
        yield return new WaitForSeconds(fireRate);
        canShoot = true;
    }
}
