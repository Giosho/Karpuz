using UnityEngine;
using UnityEngine.AI;
using System.Collections;

public class Ragdoll : MonoBehaviour
{
    private Rigidbody[] ragdollBodies;
    private Animator animator;
    private NavMeshAgent agent;

    [Header("NavMesh check")]
    [Tooltip("Distance used to sample the NavMesh when re-enabling the agent.")]
    public float navMeshSampleDistance = 1f;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
        ragdollBodies = GetComponentsInChildren<Rigidbody>();

        DeactivateRagdoll(); // start in animated state
    }

    public void ActivateRagdoll()
    {
        // Disable agent and animator influence immediately
        if (agent != null)
        {
            // stop and reset path if possible (safe guard)
            if (agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }
            agent.enabled = false;
        }

        if (animator != null)
            animator.enabled = false;

        // Make rigidbodies physical and zero any leftover velocities to avoid flinging
        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            rb.isKinematic = false;
            rb.useGravity = true;
        }

        // Extra safety: zero velocities in next physics frame in case something else applied impulses
        StartCoroutine(ZeroVelocitiesNextFixedUpdate());
    }

    public void DeactivateRagdoll()
    {
        // Turn off ragdoll physics first
        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.isKinematic = true;
            rb.useGravity = false;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Restore animator
        if (animator != null)
            animator.enabled = true;

        // Only re-enable NavMeshAgent if there's a NavMesh near the current position.
        // This avoids errors like: "Stop can only be called on an active agent that has been placed on a NavMesh."
        if (agent != null)
        {
            // Sample the NavMesh at current position
            NavMeshHit hit;
            bool found = NavMesh.SamplePosition(transform.position, out hit, navMeshSampleDistance, NavMesh.AllAreas);
            if (found)
            {
                agent.enabled = true;
                // Put agent on the navmesh at the sampled position so it doesn't throw errors
                agent.Warp(hit.position);
                agent.isStopped = false;
                agent.ResetPath();
            }
            else
            {
                // Keep agent disabled and move on.
                agent.enabled = false;
#if UNITY_EDITOR
                Debug.LogWarning($"No NavMesh found near '{gameObject.name}'. NavMeshAgent stays disabled when exiting ragdoll.");
#endif
            }
        }
    }

    private IEnumerator ZeroVelocitiesNextFixedUpdate()
    {
        // Wait for physics to run once so rigidbodies are fully active,
        // then clear velocities to avoid any impulses applied during activation.
        yield return new WaitForFixedUpdate();

        foreach (var rb in ragdollBodies)
        {
            if (rb == null) continue;
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }
}
